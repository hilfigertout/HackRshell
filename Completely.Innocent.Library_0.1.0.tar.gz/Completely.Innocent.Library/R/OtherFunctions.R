# In this file, you can add other functions. This could
# potentially include legitimate statistics functions that
# might convince some poor, unsuspecting grad student
# to load this library and start a reverse shell session.
# Just make sure to document them.
