# In this file, you can add any functions that might
# convince some poor, unsuspecting grad student
# to load this library and start a session.
# Just make sure to document them.
